import { StreetFighterGame } from './StreetFighterGame.js';

window.onload = () => {
	new StreetFighterGame().start();
};
