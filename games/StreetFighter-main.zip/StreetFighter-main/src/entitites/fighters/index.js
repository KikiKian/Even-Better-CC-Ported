export { Ken } from "./Ken.js";
export { Ryu } from "./Ryu.js";
