// 1 = 100% 2 = 200% , 0.5 = 50% half
// ONLY SHOULD BE USED FOR DEBUGGING
export let GAME_SPEED = 1;
export const FPS = 60;
export const FRAME_TIME = 1000 / FPS;
